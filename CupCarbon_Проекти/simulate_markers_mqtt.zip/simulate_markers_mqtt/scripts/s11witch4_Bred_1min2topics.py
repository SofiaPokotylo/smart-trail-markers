import sys
from paho.mqtt import client as mqtt_client
import time
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code ", rc, flush=True)

    # Set Connecting Client ID
    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client,t,topic1):
    data = {
        "type":1,
        "trail-id": 1,
        "marker-id":3,
        "temp": 1,
        "temperature": t,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic1, json_data)
    print("Published:", json_data, flush=True)


def run():
    client = connect_mqtt()
    client.loop_start()
    topic = "cupcarbon/lamp"
    while True:
        t = 32
        publish(client,t,topic)
        time.sleep(20)
        topic = "cupcarbon/another-topic"
        t = t+1
        publish(client,t,topic)
        time.sleep(60)


if __name__ == '__main__':
    run()
