# You should define the values of:
# the broker (line 9)
# the topic (line 13)
# the client id (line 17)
import sys
from paho.mqtt import client as mqtt_client
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id


def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code", rc, flush=True)

    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        message = msg.payload.decode()
        # Parse JSON message
        try:
            data = json.loads(message)
            # Print received data
            print("Received JSON data:", data, flush=True)
            # Extract and print specific values
            temperature = data.get("temperature")
            humidity = data.get("humidity")
            sensor_id = data.get("sensor-id")
            if temperature is not None:
                print("print Temperature:", temperature, flush=True)
            if humidity is not None:
                print("print Humidity:", humidity, flush=True)
        except json.JSONDecodeError as e:
            print("Error decoding JSON:", e, flush=True)

    client.subscribe(topic)
    client.on_message = on_message


def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()


if __name__ == '__main__':
    run()

