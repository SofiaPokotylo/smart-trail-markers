import sys
from paho.mqtt import client as mqtt_client
import time
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code ", rc, flush=True)

    # Set Connecting Client ID
    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client):
    data = {
        "type":0,
        "trail-id": 1,
        "marker-id":3,
        "temperature": 32,
        "rainfall": 0.2,
        "windspeed": 5,
        "impulses": 0,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)


def run():
    client = connect_mqtt()
    client.loop_start()
    while True:
        publish(client)
        time.sleep(5.5)


if __name__ == '__main__':
    run()
