import sys
from paho.mqtt import client as mqtt_client
import time
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code ", rc, flush=True)

    # Set Connecting Client ID
    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client,t,r,w,i):
    data = {
        "type":0,
        "trail-id": 1,
        "marker-id":3,
        "temperature": t,
        "rainfall": r,
        "windspeed": w,
        "impulses": i,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)


def run():
    client = connect_mqtt()
    client.loop_start()
    while True:
        t = 32
        r = 0.2
        w = 5
        i = 0
        publish(client,t,r,w,i)
        time.sleep(60)
        t = t+1
        r = r+1
        w = w+1
        i = i+1


if __name__ == '__main__':
    run()
