
print("print HELLO WORLD!", flush=True)
