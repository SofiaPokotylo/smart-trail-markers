import sys
from paho.mqtt import client as mqtt_client
import time
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code ", rc, flush=True)

    # Set Connecting Client ID
    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client, temperature, humidity, sensor_id):
    data = {
        "temperature": temperature,
        "humidity": humidity,
        "sensor-id": sensor_id
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)


def run():
    client = connect_mqtt()
    client.loop_start()
    while True:
        temperature = 24
        humidity = 15
        sensor_id = 1
        publish(client, temperature, humidity, sensor_id)
        time.sleep(0.5)


if __name__ == '__main__':
    run()
