import time

while True:
	print("mark", flush=True)
	time.sleep(1)
	print("unmark", flush=True)
	time.sleep(1)
