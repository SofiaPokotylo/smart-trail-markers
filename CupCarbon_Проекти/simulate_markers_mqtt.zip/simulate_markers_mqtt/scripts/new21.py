import sys
from paho.mqtt import client as mqtt_client
import time
import json

# Broker
broker = "broker.hivemq.com"
port = 1883

# Topic
topic = "cupcarbon/lamp"

print("getid", flush=True)
id = input()
client_id = "cupcarbon" + id

import random

def random_between(min_val, max_val):
    return random.uniform(min_val, max_val)


def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!", flush=True)
        else:
            print("Failed to connect, return code ", rc, flush=True)

    # Set Connecting Client ID
    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish_data(client,t,r,w,i):
    data = {
        "type":0,
        "trail-id": 1,
        "marker-id":id,
        "rainfall": r,
        "windspeed": w,
        "impulses": i,
        "temperature": t,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)

def publish_all_data(client,t,r,w,i,wd,hum,press,cl):
    data = {
        "type": 9,
        "trail-id": 1,
        "marker-id":id,
        "rainfall": r,
        "windspeed": w,
        "impulses": i,
        "temperature": t,
	"windirection": wd,
	"humidity": hum,
	"pressure": press,
	"cloudiness": cl,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)

def publish_warn(client,k,t,v):
    data = {
        "type":k,
        "trail-id": 1,
        "marker-id":id,
        "temp": t,
        "value": v,
        "sensor-id": 1
    }
    json_data = json.dumps(data)
    client.publish(topic, json_data)
    print("Published:", json_data, flush=True)



def run():
    client = connect_mqtt()
    client.loop_start()
    topic = "cupcarbon/lamp"
    while True:
        
        t = 32
        r = 0.2
        w = 5
        i = 0
        publish(client,t,r,w,i,topic)
        time.sleep(20)
        topic = "cupcarbon/another-topic"
        t = t+1
        r = r+1
        w = w+1
        i = i+1
        publish(client,t,r,w,i,topic)
        time.sleep(60)


if __name__ == '__main__':
    run()
